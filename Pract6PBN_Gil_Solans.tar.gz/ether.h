#ifndef ETHER_H
#define ETHER_H

#include <stdint.h>


void ether_init(void);

void ether_put(uint8_t c);

#endif
