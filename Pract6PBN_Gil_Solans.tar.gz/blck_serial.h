#ifndef BLCK_SERIAL_H
#define BLCK_SERIAL_H

#include <stdint.h>

void print(char s[]);

int readline(char s[], uint8_t m);

#endif
